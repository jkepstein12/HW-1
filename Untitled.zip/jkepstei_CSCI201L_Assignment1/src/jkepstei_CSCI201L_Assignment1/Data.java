package jkepstei_CSCI201L_Assignment1;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import com.google.gson.JsonObject;

public class Data {
	public ArrayList<Restaurant> data;
	
	public void printRestaurants(double lat1, double long1) {
		for(int i = 0; i < data.size(); i++) {			
			System.out.println(data.get(i).getName() + ", located " + 
					data.get(i).calcDistance(lat1, long1) + 
					" miles away at " + data.get(i).getAddress());
		}
	}
	
	public void printInformation(int index, double latitude, double longitude) {
		System.out.println(data.get(index).getName() + ", located " + 
				data.get(index).calcDistance(latitude, longitude) + 
				" miles away at " + data.get(index).getAddress());
	}
	
	public void addRestaurant() {
		Scanner s2 = new Scanner(System.in);
		int option = 1;
		String temp;
		Restaurant newRest = new Restaurant();
		boolean proceed = false;
		
		System.out.println("What is the name of the restaurant you would like to add?");
		newRest.setName(s2.nextLine());
		
		System.out.println("What is the address for " + newRest.getName() +  "?");
		newRest.setAddress(s2.nextLine());
		
		while(!proceed) {
			// collect user data for latitude and longitude
			System.out.println("What is the latitude for " + newRest.getName() +  "?");
			double latitude;
			temp = s2.nextLine();
			try {
				latitude = Double.parseDouble(temp);
			}
			catch (NumberFormatException nfe) {
				System.out.println("Not a valid latitude.");
				continue;
			}
			if(latitude > 90 || latitude < -90) {
				System.out.println("Not a valid latitude.");
				continue;
			}
			proceed = true;
		}
		
		proceed = false;
		while(!proceed) {
			System.out.println("What is the longitude for " + newRest.getName() +  "?");
			double longitude;
			temp = s2.nextLine();
			try {
				longitude = Double.parseDouble(temp);
			}
			catch (NumberFormatException nfe) {
				System.out.println("Not a valid longitude.");
				continue;
			}
			if(longitude > 180 || longitude < -180) {
				System.out.println("Not a valid longitude.");
				continue;
			}
			proceed = true;
		}
		proceed = false;
		
		ArrayList<String> newMenu = new ArrayList<String>();
		while(option != 2) {
			System.out.println("What does " + newRest.getName() + " serve?");			
			temp = s2.nextLine();
			
			newMenu.add(temp);
								
			System.out.println("Does " + newRest.getName() + " serve anything else?");
			System.out.println("	1) Yes");
			System.out.println("	2) No");
			
			temp = s2.nextLine();
			option = Integer.parseInt(temp);
		}
		newRest.menu = newMenu;
		data.add(newRest);
	}

	public void deleteRestaurant() {
		int option;
		String temp;
		Scanner s = new Scanner(System.in);
		
		for(int i = 0; i < data.size(); i++) {
			System.out.println("	" + (i+1) + ") " + data.get(i).getName());
		}
		
		System.out.println("Which restaurant would you like to remove?");
		temp = s.nextLine();
		option = Integer.parseInt(temp);
		
		
		System.out.println(data.get(option-1).getName() + " is now removed.");
		data.remove(option - 1);

	}
	
	public void sortAlpha() {
		Collections.sort(data, (a,b) -> a.getName().compareToIgnoreCase(b.getName()));
		System.out.println("Your restaurants are now sorted from A to Z.");	
	}
	public void sortReverseAlpha() {
		Collections.sort(data, (a,b) -> a.getName().compareToIgnoreCase(b.getName()));
		Collections.reverse(data);
		System.out.println("Your restaurants are now sorted from Z to A.");
	}
	
	public void sortCloseToFar(double lat1, double long1) {
		Collections.sort(data, (a,b) -> a.calcDistance(lat1, long1).compareToIgnoreCase
				(b.calcDistance(lat1, long1)));
		System.out.println("Your restaurants are now sorted from closest to farthest.");
	}
	
	public void sortFarToClose(double lat1, double long1) {
		Collections.sort(data, (a,b) -> a.calcDistance(lat1, long1).compareToIgnoreCase
				(b.calcDistance(lat1, long1)));
		Collections.reverse(data);
		System.out.println("Your restaurants are now sorted from farthest to closest.");
	}
	
	public void searchForRestaurant(double latitude, double longitude) {
		String searchRestaurant;
		Scanner s = new Scanner(System.in);
		boolean found = false;
		
		System.out.println("What is the name of the restaurant that you would like to search"
				+ "for?");
		searchRestaurant = s.nextLine();
		
		for(int i = 0; i < data.size(); i++) {
			if(data.get(i).getName().contains(searchRestaurant)) {
				printInformation(i, latitude, longitude);
				found = true;
			}
		}	
		if(found == false) {
			System.out.println(searchRestaurant + " could not be found.");
		}
	}
	
	public void searchForFood() {
		boolean found = false;
		Scanner s = new Scanner(System.in);
		String searchFood;
		ArrayList<String> foodMenu = new ArrayList<String>();
	
		System.out.println("Which menu item would you like to search for?");
		searchFood = s.nextLine();
		
		for(int i = 0; i < data.size(); i++) {
			for(int j = 0; j < data.get(i).menu.size(); j++) {
				if(data.get(i).menu.get(j).contains(searchFood)) {
					foodMenu.add(data.get(i).menu.get(j));
					found = true;
				}
			}
			
			if(foodMenu.size() != 0) {
				System.out.print(data.get(i).getName() + " serves ");
				for(int k = 0; k < foodMenu.size(); k++) {
					if (k != 0 && foodMenu.size() - k == 1){
						System.out.print("and " + foodMenu.get(k));
					}
					else if(foodMenu.size() - k > 1) {
						System.out.print(foodMenu.get(k) + ", ");
					}
					else {
						System.out.print(foodMenu.get(k) + " ");
					}
				}
			}
			System.out.println();
			foodMenu.clear();
		}	
		if(found == false) {
			System.out.println("No restaurant nearby serves " + searchFood);
		}
	}
}


