package jkepstei_CSCI201L_Assignment1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import com.google.gson.Gson;
import com.google.gson.JsonParseException;

public class Main {
	public static void main(String args[]) {	
		// declaration of objects
		
		int option = 0;
		Scanner s1 = new Scanner(System.in);
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		Gson gson = null;
		Data data = new Data();
		Execute main = new Execute();
		boolean proceed = false; // has not found a valid file
		String fileName = "";
		String temp = "";
		
		while(!proceed) {
			System.out.println("What is the name of the restaurant file?");
			fileName = s1.nextLine();
			
			try {	
				fileReader = new FileReader(fileName);
				bufferedReader = new BufferedReader(fileReader);
				
				try {
					gson = new Gson();
					data = gson.fromJson(fileReader, Data.class);
					proceed = true;
				}
				catch(NumberFormatException nfe) {
					System.out.println("Data cannot be converted to the proper type.");
					proceed = false;
					continue;
				}			
			}
			catch (FileNotFoundException fnfe) {
				System.out.println("The file " + fileName + " could not be found.");
				proceed = false;
				continue;
			}
			for(int i = 0; i < data.data.size(); i++) {
				if(data.data.get(i).getName() == null || data.data.get(i).getAddress() == null ||
				   data.data.get(i).getLatitude() == 0 || data.data.get(i).getLongitude() == 0
				   || data.data.get(i).menu == null) {
					System.out.println("The file " + fileName + " is not formatted properly.");
					proceed = false;
				}
			}
		}
		System.out.println("The file has been properly read.");
				
		main.run(data);
		proceed = false;
		
		while(!proceed) {
			System.out.println("	1) Yes");
			System.out.println("	2) No");
			System.out.println("Would you like to save your edits?");
			temp = s1.nextLine();
			option = Integer.parseInt(temp);
			if(option == 1) { 
				try (FileWriter writer = new FileWriter(fileName)) {
		            gson.toJson(data, writer);
		            proceed = true;
		        } catch (IOException e) {
		            e.printStackTrace();
		            proceed = false;
		        }
			}
		}
		if(bufferedReader != null) {
			try {
				bufferedReader.close();
			} catch(IOException e) {
				e.printStackTrace();
			}
		}	
		System.out.println("Thank you for using my program!");
	}
}
