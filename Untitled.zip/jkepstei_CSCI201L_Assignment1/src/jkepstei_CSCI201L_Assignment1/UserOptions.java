package jkepstei_CSCI201L_Assignment1;

public class UserOptions {
	public void printOptions() {
		System.out.println("	1) Display all restaurants");
		System.out.println("	2) Search for a restaurant");
		System.out.println("	3) Search for a menu item");
		System.out.println("	4) Add a new restaurant");
		System.out.println("	5) Remove a restaurant");
		System.out.println("	6) Sort Restaurants");
		System.out.println("	7) Exit");
	}
	
	public void sortOptions() {
		System.out.println("	1) A to Z");
		System.out.println("	2) Z to A");
		System.out.println("	3) Closest to farthest");
		System.out.println("	4) Farthest to closest");
	}
	
	
}

