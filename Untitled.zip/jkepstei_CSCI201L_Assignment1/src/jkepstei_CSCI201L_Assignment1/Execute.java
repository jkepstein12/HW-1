package jkepstei_CSCI201L_Assignment1;

import java.util.Scanner;

import com.google.gson.JsonObject;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.Math;

public class Execute {
	public void run(Data data) {
		double latitude = 0.0;
		double longitude = 0.0;
		int option = 0;
		String temp = "";
		Scanner s2 = new Scanner(System.in);
		UserOptions menuChoices = new UserOptions();
		boolean proceed = false;
		
		while(!proceed) {
			// collect user data for latitude and longitude
			System.out.println("What is your latitude?");
			temp = s2.nextLine();
			try {
				latitude = Double.parseDouble(temp);
			}
			catch (NumberFormatException nfe) {
				System.out.println("Not a valid latitude.");
				continue;
			}
			if(latitude > 90 || latitude < -90) {
				System.out.println("Not a valid latitude.");
				continue;
			}
			proceed = true;
		}
		
		proceed = false;
		while(!proceed) {
			System.out.println("What is your longitude?");
			temp = s2.nextLine();
			try {
				longitude = Double.parseDouble(temp);
			}
			catch(NumberFormatException nfe) {
				System.out.println("Not a valid longitude.");
				continue;
			}
			if(longitude < -180 || longitude > 180) {
				System.out.println("Not a valid longitude.");
				continue;
			}
			proceed = true;
		}
		proceed = false;
		// execute the program
		while(option != 7) {
			menuChoices.printOptions();
			System.out.println("what would you like to do?");
			
			temp = s2.nextLine();
			try {
				option = Integer.parseInt(temp);
			}
			catch(NumberFormatException nfe) {
				System.out.println("Not a valid option.");
			}
			if(option > 7 | option < 1) {
				System.out.println("Not a valid option.");
			}
			else if(option == 1) { // print out all restaurants
				data.printRestaurants(latitude, longitude);
			}
			else if(option == 2) { // search for a restaurant
				data.searchForRestaurant(latitude, longitude);
			}
			else if(option == 3) { // search for a menu item
				data.searchForFood();
			}
			else if(option == 4) { // add a new restaurant
				data.addRestaurant();
			}
			else if(option == 5) { // delete a restaurant
				data.deleteRestaurant();
			}
			else if(option == 6) { // sort restaurants
				while(!proceed)	{
					menuChoices.sortOptions();
					System.out.println("How would you like to sort by?");
					temp = s2.nextLine();
					try {
						option = Integer.parseInt(temp);
					}
					catch(NumberFormatException nfe) {
						System.out.println("Not a valid option.");
						continue;
					}
					if(option > 4 | option < 1) {
						System.out.println("Not a valid option.");
						continue;
					}
					break;
				}
				//from A to Z
				if(option == 1) {
					data.sortAlpha();
				}
				// from Z to A
				else if(option == 2) {
					data.sortReverseAlpha();
				}
				// from closest to farthest
				else if(option == 3) {
					data.sortCloseToFar(latitude, longitude);
				}
				// from farthest to closest
				else if(option == 4) {
					data.sortFarToClose(latitude, longitude);
				}
			}
		}
	}
}
