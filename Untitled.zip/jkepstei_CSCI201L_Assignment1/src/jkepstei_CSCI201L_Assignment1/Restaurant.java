package jkepstei_CSCI201L_Assignment1;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class Restaurant {
	private String name;
	private String address;
	private double latitude;
	private double longitude;
	public ArrayList<String> menu;
	
	// setters and getters
	public void setName(String n) {
		name = n;
	}
	public String getName() {
		return name;
	}
	
	
	public void setAddress(String add) {
		address = add;
	}
	public String getAddress() {
		return address;
	}
	
	
	public void setLatitude(double lat) {
		latitude = lat;
	}
	public double getLatitude() {
		return latitude;
	}
	
	
	public void setLongitude(double lon) {
		latitude = lon;
	}
	public double getLongitude() {
		return longitude;
	}
	
	public String calcDistance(double lat1, double long1) {
		double latRad1 = Math.toRadians(lat1);
		double latRad2 = Math.toRadians(latitude);
		double longRad1 = Math.toRadians(long1);
		double longRad2 = Math.toRadians(longitude);
		
		double distance = 3963.0 * Math.acos(Math.sin(latRad1) * Math.sin(latRad2) + 
		                  Math.cos(latRad1) * Math.cos(latRad2) * 
		                  Math.cos(longRad2 - longRad1)); 
		
		DecimalFormat numberFormat = new DecimalFormat("#.0");
		return numberFormat.format(distance);
	}
	
}
